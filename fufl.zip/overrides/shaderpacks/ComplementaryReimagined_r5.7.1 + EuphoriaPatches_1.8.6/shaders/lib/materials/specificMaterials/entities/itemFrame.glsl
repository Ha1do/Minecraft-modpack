noSmoothLighting = true;
